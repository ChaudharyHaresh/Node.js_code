const { Product } = require("../models/product");
const express = require("express");
const { Category } = require("../models/category");
const router = express.Router();

router.get(`/`, async (req, res) => {
  const productList = await Product.find();

  if (!productList) {
    res.status(500).json({ success: false });
  }
  res.send(productList);
});

module.exports = router;

// {
//   "name":"Milk",
//   "description":"Gold",
//   "richDescription":"Amul Gold",
//   "brand":"Amul",
//   "price":32,
//   "category":"63c9291675a39da045548a8c",
//   "countInStock":100,
//   "rating":4,
//   "numReviews":5,
//   "isFeatured":true
// }
